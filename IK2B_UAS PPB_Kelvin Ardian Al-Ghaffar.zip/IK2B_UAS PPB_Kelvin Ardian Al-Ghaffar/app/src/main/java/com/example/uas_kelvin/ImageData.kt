package com.example.uas_kelvin

data class ImageData (
    val imageUrl : String
)
package com.example.uas_kelvin

import android.content.Intent
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.Html
import android.view.Menu
import android.view.View
import android.widget.TextView
import androidx.cardview.widget.CardView
import androidx.core.content.ContextCompat
import androidx.viewpager2.widget.ViewPager2
import com.example.uas_kelvin.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity(), View.OnClickListener {

    private lateinit var binding: ActivityMainBinding
    private lateinit var adapter: ImageSliderAdapter
    private val list = ArrayList<ImageData>()
    private lateinit var dots: ArrayList<TextView>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val btnPindahFoods: CardView = findViewById(R.id.Makananminuman)
        btnPindahFoods.setOnClickListener(this)

        val btnPindahRumah: CardView = findViewById(R.id.Rumah)
        btnPindahRumah.setOnClickListener(this)

        val btnPindahBayi: CardView = findViewById(R.id.Bayi)
        btnPindahBayi.setOnClickListener(this)

        val btnPindahKesehatan: CardView = findViewById(R.id.Kesehatan)
        btnPindahKesehatan.setOnClickListener(this)

        list.add(
            ImageData(
                "https://s1.bukalapak.com/uploads/content_attachment/6cb05df120e8d762f7cea1c5/original/american_breakfast.jpg"
            )
        )
        list.add(
            ImageData(
                "https://i.insider.com/5ee799f619182412d631a997?width=1136&format=jpeg"
            )
        )
        list.add(
            ImageData(
                "https://cdn.smartkiddo.com/uploads/cache/products/20190412/1555047186-mbg2017-4-900.jpg"
            )
        )
        list.add(
            ImageData(
                "https://dwpinsider.com/blog/wp-content/uploads/2021/06/freepik.gif"
            )
        )
        list.add(
            ImageData(
                "https://www.logoskill.com/Images/Food/Food-14.webp"
            )
        )
        list.add(
            ImageData(
                "https://webstockreview.net/images/clipart-kitchen-logo-7.png"
            )
        )
        list.add(
            ImageData(
                "https://thumbs.dreamstime.com/b/mother-baby-stylized-vector-symbol-mom-huges-her-child-logo-template-83529717.jpg"
            )
        )
        list.add(
            ImageData(
                "https://th.bing.com/th/id/OIP.TInJZlETJne6v9zQYpjoIgHaHa?w=202&h=201&c=7&r=0&o=5&dpr=1.5&pid=1.7"
            )
        )
        adapter = ImageSliderAdapter(list)
        binding.ViewPager.adapter = adapter
        dots = ArrayList()
        setIndicator()

        binding.ViewPager.registerOnPageChangeCallback(object : ViewPager2.OnPageChangeCallback(){
            override fun onPageSelected(position: Int) {
                selectedDot(position)
                super.onPageSelected(position)
            }
        })
    }

    private fun selectedDot(position: Int) {
        for(i in 0 until list.size){
            if(i == position)
                dots[i].setTextColor(ContextCompat.getColor(this, R.color.grey))
            else
                dots[i].setTextColor(ContextCompat.getColor(this, R.color.white))
        }
    }

    private fun setIndicator() {
        for(i in 0 until list.size){
            dots.add(TextView(this))
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                dots[i].text = Html.fromHtml("&#9679", Html.FROM_HTML_MODE_LEGACY).toString()
            }else{
                dots[i].text = Html.fromHtml("&#9679")
            }
            dots[i].textSize = 18f
            binding.dotsIndicator.addView(dots[i])
        }
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        // Inflate the menu; this adds items to the action bar if it is present.
        menuInflater.inflate(R.menu.main, menu)
        return true
    }

    override fun onClick(v: View) {
        when(v.id) {
            R.id.Makananminuman -> {
                val PindahFoods = Intent(this, MakanMinumActivity::class.java)
                startActivity(PindahFoods)
            }

            R.id.Rumah-> {
                val PindahRumah = Intent(this, RumahActivity::class.java)
                startActivity(PindahRumah)
            }

            R.id.Bayi-> {
                val PindahBayi = Intent(this, BabyActivity::class.java)
                startActivity(PindahBayi)
            }

            R.id.Kesehatan-> {
                val PindahKesehatan = Intent(this, KesehatanActivity::class.java)
                startActivity(PindahKesehatan)
            }
        }
    }
}
